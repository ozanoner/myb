g++ t3.cpp -Iinclude -Llib -lcurl -std=c++14 && a.exe

downloads:
https://github.com/vszakats/harbour-deps
https://whoshuu.github.io/cpr/introduction.html

test:
http://www.httpbin.org/
https://jsonplaceholder.typicode.com/


docs:
https://github.com/typicode/jsonplaceholder#how-to
https://whoshuu.github.io/cpr/introduction.html